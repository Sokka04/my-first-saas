/**
 * Injection nav + footer + menu mobile (pages marketing Skoolis).
 */
(function () {
    function navMarkup(prefix) {
        prefix = prefix || '';
        return (
            '<header class="global-nav" role="banner">' +
            '<div class="global-nav-container">' +
            '<a href="' + prefix + 'index.html" class="nav-logo">Skoolis</a>' +
            '<ul class="nav-links" role="list">' +
            '<li><a href="' + prefix + 'produit.html">Produit</a></li>' +
            '<li><a href="' + prefix + 'hors-ligne.html">Hors-ligne</a></li>' +
            '<li><a href="' + prefix + 'modules.html">Modules</a></li>' +
            '<li><a href="' + prefix + 'tarifs.html">Tarifs</a></li>' +
            '<li><a href="' + prefix + 'demo.html">Démo</a></li>' +
            '<li><a href="' + prefix + 'faq.html">FAQ</a></li>' +
            '</ul>' +
            '<div class="nav-actions">' +
            '<a href="' + prefix + 'connexion.html" class="nav-link-secondary">Connexion</a>' +
            '<a href="' + prefix + 'essai-gratuit.html" class="nav-cta"><i class="fa-solid fa-bolt"></i> Essai gratuit</a>' +
            '</div>' +
            '<button type="button" class="nav-hamburger" aria-label="Ouvrir le menu" aria-expanded="false">' +
            '<span></span><span></span>' +
            '</button>' +
            '</div>' +
            '</header>' +
            '<div class="nav-mobile-menu" id="sk-nav-mobile" aria-hidden="true">' +
            '<a href="' + prefix + 'produit.html">Produit</a>' +
            '<a href="' + prefix + 'hors-ligne.html">Hors-ligne</a>' +
            '<a href="' + prefix + 'modules.html">Modules</a>' +
            '<a href="' + prefix + 'tarifs.html">Tarifs</a>' +
            '<a href="' + prefix + 'demo.html">Démo</a>' +
            '<a href="' + prefix + 'faq.html">FAQ</a>' +
            '<a href="' + prefix + 'connexion.html">Connexion</a>' +
            '<a href="' + prefix + 'essai-gratuit.html" class="nav-cta"><i class="fa-solid fa-bolt"></i> Essai gratuit</a>' +
            '</div>'
        );
    }

    function footerMarkup(prefix) {
        prefix = prefix || '';
        var y = new Date().getFullYear();
        return (
            '<footer role="contentinfo">' +
            '<div class="footer-container">' +
            '<nav class="footer-nav" aria-label="Liens pied de page">' +
            '<ul class="footer-links">' +
            '<li><a class="footer-link" href="' + prefix + 'index.html">Accueil</a></li>' +
            '<li><a class="footer-link" href="' + prefix + 'produit.html">Produit</a></li>' +
            '<li><a class="footer-link" href="' + prefix + 'hors-ligne.html">Hors-ligne</a></li>' +
            '<li><a class="footer-link" href="' + prefix + 'tarifs.html">Tarifs</a></li>' +
            '<li><a class="footer-link" href="' + prefix + 'demo.html">Démo</a></li>' +
            '<li><a class="footer-link" href="' + prefix + 'faq.html">FAQ</a></li>' +
            '<li><a class="footer-link" href="' + prefix + 'contact.html">Contact</a></li>' +
            '</ul>' +
            '</nav>' +
            '<div class="footer-legal">' +
            '<p class="copyright">© ' +
            y +
            ' Skoolis. Tous droits réservés.</p>' +
            '<ul class="footer-legal-links">' +
            '<li><a class="footer-link" href="' + prefix + 'mentions-legales.html">Mentions légales</a></li>' +
            '<li><a class="footer-link" href="' + prefix + 'confidentialite.html">Confidentialité</a></li>' +
            '<li><a class="footer-link" href="' + prefix + 'conditions-utilisation.html">Conditions</a></li>' +
            '</ul>' +
            '</div>' +
            '</div>' +
            '</footer>'
        );
    }

    function initNav() {
        var path = window.location.pathname || '';
        var inSubfolder = path.indexOf('/pages/') !== -1;
        var prefix = inSubfolder ? '../' : '';

        var navHost = document.getElementById('sk-nav');
        var footHost = document.getElementById('sk-footer');
        if (navHost) {
            navHost.innerHTML = navMarkup(prefix);
        }
        if (footHost) {
            footHost.innerHTML = footerMarkup(prefix);
        }

        var btn = document.querySelector('.nav-hamburger');
        var mobile = document.getElementById('sk-nav-mobile');
        if (btn && mobile) {
            btn.addEventListener('click', function () {
                var open = btn.classList.toggle('open');
                mobile.classList.toggle('open', open);
                btn.setAttribute('aria-expanded', open ? 'true' : 'false');
                mobile.setAttribute('aria-hidden', open ? 'false' : 'true');
            });
            mobile.querySelectorAll('a').forEach(function (a) {
                a.addEventListener('click', function () {
                    btn.classList.remove('open');
                    mobile.classList.remove('open');
                    btn.setAttribute('aria-expanded', 'false');
                    mobile.setAttribute('aria-hidden', 'true');
                });
            });
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initNav);
    } else {
        initNav();
    }
})();
