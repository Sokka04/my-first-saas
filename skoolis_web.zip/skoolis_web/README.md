# skoolis_web

Page d’accueil marketing (HTML + `skoolis.css` + `skoolis-nav.js`). Les formulaires pointent vers `essai-gratuit.html` et `connexion.html` (à relier plus tard à `skoolis_api`).

## Afficher dans le navigateur

À la racine de ce dossier :

```bash
npm run dev
```

Puis ouvrir l’URL affichée (souvent **http://localhost:5173**).

Sans npm : ouvrir `index.html` dans le navigateur (double-clic), ou depuis ce dossier :

```bash
npx --yes serve . -l 5173
```

## Fichiers

| Fichier | Rôle |
|---------|------|
| `index.html` | Landing |
| `skoolis.css` | Styles |
| `skoolis-nav.js` | Barre de navigation + pied de page injectés |
| `essai-gratuit.html` | Onboarding essai gratuit |
| `connexion.html` | Accès école / parents / administration |
| `demo.html` | Démo (assets à intégrer) |
| `tarifs.html` | Tarifs détaillés + devis |
| `hors-ligne.html` | Page stratégique offline |
| `modules.html` | Catalogue modules |
| `produit.html` | Vue globale du système |
| `contact.html` | Contact |
| `faq.html` | FAQ par catégories (SEO) |
| `mentions-legales.html` | Mentions légales |
| `confidentialite.html` | Confidentialité |
| `conditions-utilisation.html` | Conditions d’utilisation |
| `faq.html` | FAQ + ancre `#paiement` |

## Plus tard (app + API)

Pour une SPA (Vite + Vue/React) qui consomme uniquement `skoolis_api` :

```bash
npm create vite@latest . -- --template vue-ts
```

Configurer `VITE_API_URL` et Sanctum selon votre mode d’auth.
